from utils import pad_sents

sents = [['i','am','ok'],['you'],[]]
sents_padded = pad_sents(sents,'#')
print(sents)
print(sents_padded)
